import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class RoomSearch extends javax.swing.JFrame {
    Connection conn=null;
    ResultSet rs=null;
    boolean workAs;
    String Id;
    PreparedStatement pst=null;
    public RoomSearch(boolean Worker,String id) {
        workAs=Worker;
        Id=id;
        initComponents();
        try
        {
             Class.forName("com.mysql.jdbc.Driver");
             System.out.println("driver loaded.....");
             conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/subrata","root","Subrata1@das");
             System.out.println("connection established....");
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("exception cought "+e.getMessage());
        }
        catch(SQLException e)
        {
             System.out.println("exception cought "+e.getMessage());
        }
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Room = new javax.swing.JTable();
        Advanced_search = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Avl_room = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        back = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        room_no = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        check_in = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        check_out = new javax.swing.JTextField();
        Add_Guest = new javax.swing.JButton();
        Clear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Room's", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 18))); // NOI18N

        Room.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        Room.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Room number", "A/C", "Double", "Price", "Status", "Occoupied by", "Checkin Date", "Cheakout Date"
            }
        ));
        Room.setAlignmentX(2.0F);
        Room.setAlignmentY(2.0F);
        Room.setRowHeight(35);
        jScrollPane1.setViewportView(Room);

        Advanced_search.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Advanced_search.setText("Advance search");
        Advanced_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Advanced_searchActionPerformed(evt);
            }
        });

        jLabel1.setText("Number of rooms available");

        jLabel2.setText("A/C");

        jLabel3.setText("Double");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(333, 333, 333)
                .addComponent(jLabel1)
                .addGap(53, 53, 53)
                .addComponent(Avl_room, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(jLabel3)
                .addGap(26, 26, 26)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(763, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(Advanced_search, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(Advanced_search, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 481, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Avl_room, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39))
        );

        back.setBackground(new java.awt.Color(153, 255, 153));
        back.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        back.setForeground(new java.awt.Color(0, 0, 153));
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel4.setText("Name");

        jLabel5.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel5.setText("Check in");

        name.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel6.setText("Room Number");

        room_no.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel7.setText("Phone");

        phone.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        check_in.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel8.setText("Check out");

        check_out.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        Add_Guest.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        Add_Guest.setText("Add Guest");
        Add_Guest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_GuestActionPerformed(evt);
            }
        });

        Clear.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Add_Guest)
                        .addGap(121, 121, 121)
                        .addComponent(Clear))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(check_in, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(79, 79, 79)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(room_no)
                    .addComponent(check_out, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(117, 117, 117)
                .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(111, 111, 111))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(room_no, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(check_in, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(check_out, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Add_Guest)
                    .addComponent(Clear))
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(201, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    void display(boolean ac, boolean dbl)
    {
        String quary;
          try
            {
                if(ac==true&&dbl==false)
                {
                    quary="select * from room where ac='yes' and double_single='single' and status='free'";
                    pst=conn.prepareStatement(quary);
                    rs=pst.executeQuery();
                    Room.setModel(DbUtils.resultSetToTableModel(rs));
                    if(Room.getRowCount()==0)
                         JOptionPane.showMessageDialog(null,"Sorry no room is available..");
                }
                else if(dbl==true&&ac==false)
                {
                     quary="select * from room where double_single='double' and ac='no' and status='free'";
                     pst=conn.prepareStatement(quary);
                     rs=pst.executeQuery();
                     Room.setModel(DbUtils.resultSetToTableModel(rs));
                     if(Room.getRowCount()==0)
                         JOptionPane.showMessageDialog(null,"Sorry no room is available..");
                }
                else if(dbl==true&&ac==true)
                {
                     quary="select * from room where double_single='double' and ac='no' and status='free'";
                     pst=conn.prepareStatement(quary);
                     rs=pst.executeQuery();
                     Room.setModel(DbUtils.resultSetToTableModel(rs));
                     if(Room.getRowCount()==0)
                         JOptionPane.showMessageDialog(null,"Sorry no room is available..");
                } 
                else
                {
                     quary="select * from room where status='free'";
                     pst=conn.prepareStatement(quary);
                     rs=pst.executeQuery();
                     Room.setModel(DbUtils.resultSetToTableModel(rs));
                     if(Room.getRowCount()==0)
                         JOptionPane.showMessageDialog(null,"Sorry no room is available..");
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,e);

            }
          finally
          {
            try
            {
               rs.close();
               pst.close();
            }
                catch(Exception e)
                {}
          }
    }
    private void Advanced_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Advanced_searchActionPerformed
        try
        {
             String quary="select * from room";
             pst=conn.prepareStatement(quary);
             rs=pst.executeQuery();
             Room.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null,e);

        }
        finally
        {
           try
           {
               rs.close();
               pst.close();
           }
           catch(Exception e)
           {}
        }
    }//GEN-LAST:event_Advanced_searchActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        if(workAs==true)
        {
             new  Manager(Id).setVisible(true);
             dispose();
        }
        else
        {
             new Employee(Id).setVisible(true);
             dispose();
        }
    }//GEN-LAST:event_backActionPerformed

    private void Add_GuestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_GuestActionPerformed
         if(!name.getText().equals("")&&!room_no.getText().equals("")&&!phone.getText().equals("")&&!check_in.getText().equals("")&&!check_out.getText().equals(""))
         {
             int sure=JOptionPane.showConfirmDialog(null," Are you sure to update","update",JOptionPane.YES_NO_OPTION);
            if(Integer.parseInt(room_no.getText())>=1&&Integer.parseInt(room_no.getText())<=10)
            {
                if(sure==0)
               {
                   try
                   {
                       String G_id=getGuestId();
                       int d=1;
                       String quary="insert into guest(name,room_no,phone_no,cheakin_date,cheakout_date,E_id) values('"+name.getText()+"',"+room_no.getText()+","+phone.getText()+",'"+check_in.getText()+"','"+check_out.getText()+"','"+G_id+"')";
                       pst=conn.prepareStatement(quary);
                       if(!pst.execute())
                       {
                           JOptionPane.showMessageDialog(null,"Guest allotment succesful.."); 
                           updateRcordRoom();
                       }
                       else
                       {
                           d=0;
                           JOptionPane.showMessageDialog(null,"Guest allotment not succesful...");
                       }
                       quary="update room set status='ocopied', reserved_by='"+name.getText()+"' where room_no="+room_no.getText();
                       pst=conn.prepareStatement(quary);
                       if(d!=0)
                      {
                           if(!pst.execute())
                               JOptionPane.showMessageDialog(null,"Room updation  succesful..");
                       else
                           JOptionPane.showMessageDialog(null,"room allotment not succesful...");
                      }
                       update_Table();
                   }
                   catch(Exception e)
                   {
                       JOptionPane.showMessageDialog(null,e);
                   }
                   finally
                   {
                       try
                       {
                           rs.close();
                           pst.close();
                       }
                       catch(Exception e)
                       {}
                   }
               }
            }
             else
               JOptionPane.showMessageDialog(null,"Room number doesnot exist..");
         }
         else
             JOptionPane.showMessageDialog(null,"fill all records..");
        
    }//GEN-LAST:event_Add_GuestActionPerformed
    
    private String getGuestId()
    {
        String id1=null;
        int id2=0;
        try
        {
          
            String query="select * from id";
            pst=conn.prepareStatement(query);
            rs=pst.executeQuery();
            rs.next();
            id1=rs.getString(1);
            int incr=id1.charAt(1);
            id2=id1.charAt(0);
            if(incr>128)
            {
                id2++;
            }
            else
                incr++;
            id1=(char)id2+incr+"a";
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        return id1;
    }
    void updateRcordRoom()
    {
        try
        {
            String in=check_in.getText();
            String out=check_out.getText();
            String temp[]=in.split("/");
            int a=Integer.parseInt(temp[0]);
            temp=out.split("/");
            int b=Integer.parseInt(temp[0]);
            int c=b-a+1;
            String quary="update recordroom set visted="+c+" where month='"+temp[1]+"' and room_no="+room_no.getText();
            //String quary="update recordroom set visted="+Integer.toString(6)+" where month='1' and room_no=9";
             pst=conn.prepareStatement(quary);
             if(!pst.execute())
             {
                 JOptionPane.showMessageDialog(null,"success Full.....");
             }
            else
              JOptionPane.showMessageDialog(null,"bakup failed.....");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
    }
    void update_Table()
    {
        
    }
    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        name.setText("");
        room_no.setText("");
        phone.setText("");
        check_in.setText("");
        check_out.setText("");
        
    }//GEN-LAST:event_ClearActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_Guest;
    private javax.swing.JButton Advanced_search;
    private javax.swing.JTextField Avl_room;
    private javax.swing.JButton Clear;
    private javax.swing.JTable Room;
    private javax.swing.JButton back;
    private javax.swing.JTextField check_in;
    private javax.swing.JTextField check_out;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField room_no;
    // End of variables declaration//GEN-END:variables
}
