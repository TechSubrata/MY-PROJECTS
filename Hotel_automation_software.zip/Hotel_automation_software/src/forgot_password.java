import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.util.concurrent.TimeUnit;
public class forgot_password extends javax.swing.JFrame {
    long start,end;
    Connection conn=null;
    int test=0;
    ResultSet rs=null;
    PreparedStatement pst=null;
    public forgot_password() {
        initComponents();
        try
        {
             Class.forName("com.mysql.jdbc.Driver");
             System.out.println("driver loaded.....");
             conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/subrata","root","Subrata1@das");
             System.out.println("connection established....");
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("exception cought "+e.getMessage());
        }
        catch(SQLException e)
        {
             System.out.println("exception cought "+e.getMessage());
        }
        
    }
    public void setTest(int t)
    {
        test=t;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        recp = new javax.swing.JRadioButton();
        manager = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Id = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        otp = new javax.swing.JButton();
        cencel = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        get_otp = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        set_password = new javax.swing.JTextField();
        Set = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        match_otp = new javax.swing.JTextField();
        back = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "GET OTP FROM HERE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24))); // NOI18N

        buttonGroup1.add(recp);
        recp.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        recp.setText("Receptionist");

        buttonGroup1.add(manager);
        manager.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        manager.setText("Manager");

        jLabel1.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel1.setText("User_Id");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel2.setText("Phone number");

        Id.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        Id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IdActionPerformed(evt);
            }
        });

        phone.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        otp.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        otp.setText("Change Password");
        otp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                otpActionPerformed(evt);
            }
        });

        cencel.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        cencel.setText("Cencel");
        cencel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cencelActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 23)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 51, 51));
        jLabel5.setText("Your OTP will be show here");

        get_otp.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        get_otp.setForeground(new java.awt.Color(204, 0, 0));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setText("OTP will work for omly 1 munute");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(recp)
                        .addGap(42, 42, 42)
                        .addComponent(manager))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(203, 203, 203)
                        .addComponent(otp)
                        .addGap(63, 63, 63)
                        .addComponent(cencel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Id, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(get_otp, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(recp)
                    .addComponent(manager))
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Id, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(73, 73, 73)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(otp)
                    .addComponent(cencel))
                .addGap(76, 76, 76)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(get_otp, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "SET PASWORD HERE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24), new java.awt.Color(0, 204, 0))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel3.setText("Enter new password");

        set_password.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        Set.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        Set.setText("Set Password");
        Set.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SetActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel4.setText("Enter OTP");

        match_otp.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(Set))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(set_password)
                            .addComponent(match_otp, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE))))
                .addContainerGap(209, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(match_otp, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(set_password, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(82, 82, 82)
                .addComponent(Set)
                .addContainerGap(164, Short.MAX_VALUE))
        );

        back.setBackground(new java.awt.Color(153, 255, 153));
        back.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        back.setForeground(new java.awt.Color(0, 0, 153));
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(back)))
                .addContainerGap(132, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(back)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 100, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IdActionPerformed

    private void otpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_otpActionPerformed
        if(recp.isSelected()||manager.isSelected())
        {
            try
            {
                if(recp.isSelected())
                {
                    String quary="select * from employee where e_id=? AND phone=? and work_as='employee'";
                    pst=conn.prepareStatement(quary);
                    pst.setString(1,Id.getText());
                    pst.setString(2,phone.getText());
                    rs=pst.executeQuery();
                    if(rs.next())
                    {
                        int rand_otp=(int )(Math.random()*10000);
                        get_otp.setText(rand_otp+"has");
                        start=System.currentTimeMillis();
                    }
                }
                else
                {
                   String quary="select * from employee where e_id=? AND phone=? and work_as='manager'";
                    pst=conn.prepareStatement(quary);
                    pst.setString(1,Id.getText());
                    pst.setString(2,phone.getText());
                    rs=pst.executeQuery();
                    if(rs.next())
                    {

                        int rand_otp=(int )(Math.random()*10000);
                        get_otp.setText(rand_otp+"has");
                        start=System.currentTimeMillis();
                    }
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
             finally
            {
                try
                {
                    rs.close();
                    pst.close();
                }
                catch(Exception e)
                {}
            }
        }
        else
            JOptionPane.showMessageDialog(null,"Chose any radio button....");
       
    }//GEN-LAST:event_otpActionPerformed

    private void cencelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cencelActionPerformed
      new Login().setVisible(true);
      dispose();
    }//GEN-LAST:event_cencelActionPerformed

    private void SetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SetActionPerformed
        end=System.currentTimeMillis();
        long difference=TimeUnit.MILLISECONDS.toMinutes(end-start);
        System.out.println(start);
        System.out.println(end);
        System.out.println(difference);
        if(difference<2)
        {
            if(get_otp.getText()==match_otp.getText())
            {
                 try
                 {
                        String quary="update employee where e_id="+Id.getText()+" AND phone="+phone.getText() ;
                        pst=conn.prepareStatement(quary);
                        rs=pst.executeQuery();
                        if(rs.next())
                             JOptionPane.showMessageDialog(null,"your password successfully updated");
                        else
                            JOptionPane.showMessageDialog(null,"try again.......");
                }
                catch(Exception e)
                {
                    JOptionPane.showMessageDialog(null,e);
                }
                 finally
                {
                    try
                    {
                        rs.close();
                        pst.close();
                    }
                    catch(Exception e)
                    {}
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null,"you entered a wrong OTP");
            }
        }
        else
            JOptionPane.showMessageDialog(null,"Time for otp is over...");
    }//GEN-LAST:event_SetActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        
        Login log=new Login();
        log.setVisible(true);
        dispose();
    }//GEN-LAST:event_backActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Id;
    private javax.swing.JButton Set;
    private javax.swing.JButton back;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton cencel;
    private javax.swing.JLabel get_otp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton manager;
    private javax.swing.JTextField match_otp;
    private javax.swing.JButton otp;
    private javax.swing.JTextField phone;
    private javax.swing.JRadioButton recp;
    private javax.swing.JTextField set_password;
    // End of variables declaration//GEN-END:variables
}
