
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ManageEmployee extends javax.swing.JFrame {
    Connection conn=null;
    ResultSet rs=null;
    String Id;
    PreparedStatement pst=null;
    public ManageEmployee(String id) {
        initComponents();
        Id=id;
        try
        {
             Class.forName("com.mysql.jdbc.Driver");
             System.out.println("driver loaded.....");
             conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/subrata","root","Subrata1@das");
             System.out.println("connection established....");
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("exception cought "+e.getMessage());
        }
        catch(SQLException e)
        {
             System.out.println("exception cought "+e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        findEmployee = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        E_name = new javax.swing.JTextField();
        E_id = new javax.swing.JTextField();
        possition = new javax.swing.JTextField();
        salary = new javax.swing.JTextField();
        Update = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        Clear = new javax.swing.JButton();
        newEmployee = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        back = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Find Employee", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel1.setText("Employee Name");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel2.setText("Employee id");

        name.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        id.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        findEmployee.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        findEmployee.setText("Enter");
        findEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findEmployeeActionPerformed(evt);
            }
        });

        clear.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        clear.setText("Clear");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(findEmployee)
                        .addGap(45, 45, 45)
                        .addComponent(clear)))
                .addContainerGap(153, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(findEmployee)
                    .addComponent(clear))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Employee Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel3.setText("Name");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel4.setText("Employee_Id");

        jLabel5.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel5.setText("Possition");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel6.setText("Salary");

        E_name.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        E_id.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        possition.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        salary.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        Update.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });

        Delete.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        Clear.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        Clear.setText("Clear");

        newEmployee.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        newEmployee.setText("New Employee");
        newEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newEmployeeActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jLabel7.setText("Phone");

        phone.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel6)))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(E_name, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE)
                            .addComponent(E_id)
                            .addComponent(possition)
                            .addComponent(salary)
                            .addComponent(phone)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Update)
                        .addGap(72, 72, 72)
                        .addComponent(Delete)
                        .addGap(46, 46, 46)
                        .addComponent(Clear)))
                .addGap(56, 56, 56)
                .addComponent(newEmployee)
                .addContainerGap(391, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(E_name, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(E_id, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(possition, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(salary, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Update)
                    .addComponent(Delete)
                    .addComponent(Clear)
                    .addComponent(newEmployee))
                .addGap(27, 27, 27))
        );

        back.setBackground(new java.awt.Color(153, 255, 153));
        back.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        back.setForeground(new java.awt.Color(0, 0, 204));
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(back)
                .addGap(80, 80, 80)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void newEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newEmployeeActionPerformed
        try
        {
            String password="hello123";
            String quary="insert into employee(salary,name,e_id,password,work_as,phone) values("+salary.getText()+",'"+E_name.getText()+"','"+E_id.getText()+"','"+password+"','"+possition.getText()+"')"+phone.getText();
            pst=conn.prepareStatement(quary);
            if(! pst.execute())
            {
                 JOptionPane.showMessageDialog(null,"Succesfully registered.....");
            }
            else
                 JOptionPane.showMessageDialog(null,"Registration not done please try again........");
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null,e);
        }
        finally
            {
                try
                {
                    rs.close();
                    pst.close();
                }
                catch(Exception e)
                {
                     JOptionPane.showMessageDialog(null,e);
                }
            }
    }//GEN-LAST:event_newEmployeeActionPerformed

    private void findEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findEmployeeActionPerformed
        try
        {
            String quary="select * from employee where name=? and e_id=?";
            pst=conn.prepareStatement(quary);
            pst.setString(1,name.getText());
            pst.setString(2,id.getText());
            rs=pst.executeQuery();
            if(rs.next())
            {
                E_name.setText(rs.getString(2));
                possition.setText(rs.getString(5));
                E_id.setText(rs.getString(3));
                salary.setText(rs.getString(1));
                phone.setText(rs.getString(6));
            }
            else
                 JOptionPane.showMessageDialog(null,"no data is there please cheake details.....");
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null,e);
        }
        finally
            {
                try
                {
                    rs.close();
                    pst.close();
                }
                catch(Exception e)
                {
                     JOptionPane.showMessageDialog(null,e);
                }
            }
    }//GEN-LAST:event_findEmployeeActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
       try
        {
            String quary="update employee set salary="+salary.getText()+",work_as='"+possition.getText()+"',phone="+phone.getText()+" where name=? AND e_id=?";
            pst=conn.prepareStatement(quary);
            pst.setString(1,E_name.getText());
            pst.setString(2,E_id.getText());
            if(! pst.execute())
            {
                 JOptionPane.showMessageDialog(null,"succesfully updated.....");
            }
            else
                 JOptionPane.showMessageDialog(null,"No employee is there please cheake details.....");
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null,e);
        }
       finally
        {
                try
                {
                    rs.close();
                    pst.close();
                }
                catch(Exception e)
                {
                   
                }
       }
    }//GEN-LAST:event_UpdateActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
       Manager manager=new Manager(Id);
       manager.setVisible(true);
        dispose();
    }//GEN-LAST:event_backActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        try
        {
            String quary="delete from employee where e_id='"+E_id.getText()+"'";
            pst=conn.prepareStatement(quary);
            if(! pst.execute())
            {
                 JOptionPane.showMessageDialog(null,"succesfully deleted.....");
            }
            else
                 JOptionPane.showMessageDialog(null,"No employee is there please cheake details.....");
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null,e);
        }
        finally
        {
                try
                {
                    rs.close();
                    pst.close();
                }
                catch(Exception e)
                {
                    
                }
        }
    }//GEN-LAST:event_DeleteActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clear;
    private javax.swing.JButton Delete;
    private javax.swing.JTextField E_id;
    private javax.swing.JTextField E_name;
    private javax.swing.JButton Update;
    private javax.swing.JButton back;
    private javax.swing.JButton clear;
    private javax.swing.JButton findEmployee;
    private javax.swing.JTextField id;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField name;
    private javax.swing.JButton newEmployee;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField possition;
    private javax.swing.JTextField salary;
    // End of variables declaration//GEN-END:variables
}
